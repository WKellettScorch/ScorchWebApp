import React from 'react';

const HomeComponent = () => {
    return (
        <div>
            {/* Your home page content goes here */}
            Welcome to the Home page!
        </div>
    );
};

export default HomeComponent;
